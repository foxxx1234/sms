// static/js/main.js

document.addEventListener('DOMContentLoaded', () => {
  //
  // Глобальные переменные, переданные из шаблона layout.html
  //
  const buttonsTrans = window.buttons;    // из translations.json → buttons
  const tabsTrans    = window.tabs;       // из translations.json → tabs
  const labelsTrans  = window.labels;     // из translations.json → table_headers
  let currentLang    = window.lang || 'en';

  //
  // Элементы DOM
  //
  const selectAllCb     = document.getElementById('select-all');
  const table           = document.getElementById('modem-table');
  const thead           = table.querySelector('thead');
  const tbody           = table.querySelector('tbody');
  const logToggleBtn    = document.getElementById('toggle-log');
  const clearLogBtn     = document.getElementById('clear-log');
  const fileLogCb       = document.getElementById('file-log');
  const logEntries      = document.getElementById('log-entries');
  const langBtns        = document.querySelectorAll('.lang-btn');
  const menuBtns        = document.querySelectorAll('nav.main-menu .menu-btn');
  const tabBtns         = document.querySelectorAll('nav.tabs-menu .tab-btn');
  const contentSections = document.querySelectorAll('main#main-content section');

  //
  // Хранилище портов и настройки сортировки
  //
  let allPorts       = [];
  let displayedCount = 20;
  let sortKey        = null;
  let sortDir        = 1;  // 1 = по возрастанию, -1 = по убыванию

  //
  // ------------ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ------------
  //

  // Добавить запись в лог
  function log(msg) {
    const line = document.createElement('div');
    const ts   = new Date().toLocaleTimeString();
    line.textContent = `[${ts}] ${msg}`;
    logEntries.appendChild(line);
    logEntries.scrollTop = logEntries.scrollHeight;
    if (fileLogCb.checked) {
      // TODO: отправить на сервер для записи в файл
    }
  }

  // Отрисовать строки таблицы на основе allPorts и displayedCount
  function renderTable() {
    tbody.innerHTML = '';
    const subset = allPorts.slice(0, displayedCount);
    subset.forEach(port => {
      const tr = document.createElement('tr');
      tr.dataset.port = port;
      let html = '';
      html += `<td><input type="checkbox" class="sel"></td>`;
      for (let key in labelsTrans) {
        const value = (key === 'port') ? port : '—';
        html += `<td class="${key}">${value}</td>`;
      }
      html += `<td class="row-actions">
        <button class="btn-connect">${buttonsTrans.connect[currentLang]}</button>
        <button class="btn-disconnect">${buttonsTrans.disconnect[currentLang]}</button>
      </td>`;
      tr.innerHTML = html;
      tbody.appendChild(tr);
    });
    log(`Rendered ${Math.min(displayedCount, allPorts.length)} of ${allPorts.length} ports`);
  }

  // Загрузить список портов с сервера
  function loadPorts() {
    fetch('/api/scan_ports')
      .then(r => r.json())
      .then(data => {
        allPorts = data.ports;
        displayedCount = 20;
        renderTable();
        log(`Scanned ports: ${allPorts.length}`);
      })
      .catch(err => log(`Scan error: ${err}`));
  }

  // Выполнить действие connect/disconnect
  function doAction(action) {
    const selected = Array.from(tbody.querySelectorAll('.sel:checked'))
                          .map(cb => cb.closest('tr').dataset.port);
    const ports = selected.length ? selected : allPorts;
    fetch(`/api/${action}`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ports})
    })
    .then(r => r.json())
    .then(res => log(`${action}: ${res.ports.join(', ')}`))
    .catch(err => log(`${action} error: ${err}`));
  }

  // Переключение вкладок
  function switchTab(tabKey) {
    tabBtns.forEach(b => b.classList.toggle('active', b.dataset.tab === tabKey));
    contentSections.forEach(sec => {
      sec.classList.toggle('hidden', sec.id !== `tab-${tabKey}`);
    });
  }

  // Сортировка по столбцу
  function sortBy(key) {
    sortDir = (sortKey === key) ? -sortDir : 1;
    sortKey = key;
    allPorts.sort((a, b) => {
      const ra = a.toLowerCase(), rb = b.toLowerCase();
      return ra < rb ? -sortDir : ra > rb ? sortDir : 0;
    });
    renderTable();
    log(`Sorted by ${key} (${sortDir>0?'asc':'desc'})`);
  }

  // Обновить все тексты на странице при смене языка
  function updateTexts() {
    // Главное меню
    menuBtns.forEach(b => {
      const act = b.dataset.action;
      b.textContent = buttonsTrans[act][currentLang];
    });
    // Вкладки
    tabBtns.forEach(b => {
      const tkey = b.dataset.tab;
      b.textContent = tabsTrans[tkey][currentLang];
    });
    // Заголовки таблицы
    thead.querySelectorAll('th.sortable').forEach(th => {
      const key = th.dataset.key;
      th.textContent = labelsTrans[key][currentLang];
    });
    // Последний header — действия
    const lastTh = thead.querySelector('th:last-child');
    lastTh.textContent = `${buttonsTrans.connect[currentLang]}/${buttonsTrans.disconnect[currentLang]}`;
    // Кнопки в строках
    tbody.querySelectorAll('.btn-connect').forEach(btn => {
      btn.textContent = buttonsTrans.connect[currentLang];
    });
    tbody.querySelectorAll('.btn-disconnect').forEach(btn => {
      btn.textContent = buttonsTrans.disconnect[currentLang];
    });
  }

  //
  // ------------ УСТАНОВКА ОБРАБОТЧИКОВ ------------
  //

  // Select All
  selectAllCb.addEventListener('change', () => {
    const checked = selectAllCb.checked;
    tbody.querySelectorAll('.sel').forEach(cb => cb.checked = checked);
  });

  // Сортировка заголовков
  thead.addEventListener('click', e => {
    const th = e.target.closest('th.sortable');
    if (!th) return;
    sortBy(th.dataset.key);
  });

  // Действия кнопок Connect/Disconnect
  document.querySelector('nav.main-menu .menu-btn[data-action="connect"]')
    .addEventListener('click', () => doAction('connect'));
  document.querySelector('nav.main-menu .menu-btn[data-action="disconnect"]')
    .addEventListener('click', () => doAction('disconnect'));

  // Заглушки для USSD, Port Find, Port Sort, Settings
  document.querySelector('nav.main-menu .menu-btn[data-action="ussd"]')
    .addEventListener('click', () => alert('USSD not implemented yet'));
  document.querySelector('nav.main-menu .menu-btn[data-action="port_find"]')
    .addEventListener('click', () => alert('Port Find not implemented yet'));
  document.querySelector('nav.main-menu .menu-btn[data-action="port_sort"]')
    .addEventListener('click', () => alert('Port Sort not implemented yet'));
  document.querySelector('nav.main-menu .menu-btn[data-action="settings"]')
    .addEventListener('click', () => alert('Settings not implemented yet'));

  // Лог: переключить видимость
  logToggleBtn.addEventListener('click', () => {
    document.getElementById('log-panel').classList.toggle('hidden');
  });
  // Очистить лог
  clearLogBtn.addEventListener('click', () => {
    logEntries.innerHTML = '';
  });

  // Вкладки
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // Смена языка без перезагрузки
  langBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const newLang = btn.dataset.lang;
      fetch('/set_language', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({lang: newLang})
      })
      .then(() => {
        currentLang = newLang;
        updateTexts();
      });
    });
  });

  //
  // ------------ ИНИЦИАЛИЗАЦИЯ ------------
  //
  // Добавляем атрибуты sortable и ключи в <th> динамически
  const headerRow = thead.querySelector('tr');
  // Первый и последний th уже в шаблоне, остальные сделаны Jinja
  // Здесь предполагается, что в шаблоне они помечены классом "sortable" и data-key

  // Загружаем порты и показываем вкладку Ports
  loadPorts();
  switchTab('ports');
});
